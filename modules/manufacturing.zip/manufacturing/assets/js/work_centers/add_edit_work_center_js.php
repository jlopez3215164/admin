<script>
	"use strict";
	
	appValidateForm($("body").find('#add_update_work_center'), {
		'work_center_name': 'required',
	});    
	
</script>