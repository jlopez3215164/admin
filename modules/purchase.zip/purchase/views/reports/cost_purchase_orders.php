<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="cost-purchase-orders-report" class="hide">
   <figure class="highcharts-figure col-md-12">
    <div id="container_cost_purchase_orders"></div>
    <p class="highcharts-description">
    </p>
</figure>
</div>

