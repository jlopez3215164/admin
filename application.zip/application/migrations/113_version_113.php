<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Version_113 extends CI_Migration
{
  function __construct()
  {
    parent::__construct();
}

public function up()
{
// Nothing to do here
// Only database version in the table tblmigrations will be updated auo
}
}
