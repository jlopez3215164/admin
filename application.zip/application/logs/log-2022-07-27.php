<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-27 14:25:25 --> Severity: Warning --> require(C:\xampp\htdocs\admin\modules\backup/vendor/autoload.php): Failed to open stream: No such file or directory C:\xampp\htdocs\admin\modules\backup\backup.php 12
ERROR - 2022-07-27 14:25:25 --> Severity: error --> Exception: Failed opening required 'C:\xampp\htdocs\admin\modules\backup/vendor/autoload.php' (include_path='\xampp\php\PEAR') C:\xampp\htdocs\admin\modules\backup\backup.php 12
