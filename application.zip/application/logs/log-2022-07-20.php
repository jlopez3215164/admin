<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-20 22:29:38 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:29:38 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cierram\modules\purchase\third_party\excel\PHPExcel\Shared\String.php 526
ERROR - 2022-07-20 22:29:46 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:29:48 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:29:52 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:29:53 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:30:00 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\cierram\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 22:30:00 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cierram\modules\purchase\third_party\excel\PHPExcel\Shared\String.php 526
ERROR - 2022-07-20 23:16:34 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\admin\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 23:16:54 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\admin\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 23:16:56 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\admin\modules\omni_sales\helpers\Omni_sales_helper.php 40
ERROR - 2022-07-20 23:16:57 --> Severity: 8192 --> Required parameter $minutes follows optional parameter $store C:\xampp\htdocs\admin\modules\omni_sales\helpers\Omni_sales_helper.php 40
