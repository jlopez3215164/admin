<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-11 07:11:54 --> Severity: Notice --> Undefined property: Invoices::$payments_model C:\laragon\www\admin\application\controllers\admin\Invoices.php 513
ERROR - 2023-05-11 07:11:54 --> Severity: error --> Exception: Call to a member function printBill() on null C:\laragon\www\admin\application\controllers\admin\Invoices.php 513
ERROR - 2023-05-11 07:12:59 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:13:22 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:14:49 --> Severity: error --> Exception: Call to undefined method Payment_modes_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 515
ERROR - 2023-05-11 07:17:10 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 515
ERROR - 2023-05-11 07:17:16 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 515
ERROR - 2023-05-11 07:17:20 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 515
ERROR - 2023-05-11 07:17:24 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 515
ERROR - 2023-05-11 07:19:18 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 11:20:03 --> 404 Page Not Found: admin/Invoices/get_invoice_payments
ERROR - 2023-05-11 07:20:05 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:20:07 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:20:50 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:20:52 --> Severity: error --> Exception: Call to undefined method Payments_model::printBill() C:\laragon\www\admin\application\controllers\admin\Invoices.php 514
ERROR - 2023-05-11 07:22:26 --> Severity: Notice --> Undefined variable: invoiceid C:\laragon\www\admin\application\models\Payments_model.php 50
ERROR - 2023-05-11 07:22:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: UPDATE tblinvoices SET is_print_fiscal = 1 where id = 
ERROR - 2023-05-11 11:56:15 --> 404 Page Not Found: /index
ERROR - 2023-05-11 12:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-11 13:05:14 --> 404 Page Not Found: /index
ERROR - 2023-05-11 13:14:08 --> 404 Page Not Found: /index
ERROR - 2023-05-11 14:23:35 --> 404 Page Not Found: /index
