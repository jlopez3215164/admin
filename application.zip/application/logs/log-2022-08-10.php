<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-10 12:13:00 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\admin\modules\purchase\third_party\excel\PHPExcel\ReferenceHelper.php 884
ERROR - 2022-08-10 12:13:03 --> Could not find the language line "_please_select_a_file"
ERROR - 2022-08-10 12:13:09 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\admin\modules\purchase\third_party\excel\PHPExcel\ReferenceHelper.php 884
ERROR - 2022-08-10 12:13:18 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\admin\modules\purchase\third_party\excel\PHPExcel\ReferenceHelper.php 884
ERROR - 2022-08-10 12:13:25 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\admin\modules\purchase\third_party\excel\PHPExcel\ReferenceHelper.php 884
ERROR - 2022-08-10 12:13:41 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\admin\modules\purchase\third_party\excel\PHPExcel\ReferenceHelper.php 884
